# tugas-mobile-computing-18030036
 
